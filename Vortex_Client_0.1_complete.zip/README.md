# Vortex Client 0.1 (AndroidIDE project)

This is a complete Android source project structure for the Vortex floating-tools prototype.
Open the **vortex_client** folder in AndroidIDE and use its Gradle/Build action.

## Prototype features
- Overlay permission onboarding
- Floating V button
- Expand/collapse soft-styled menu
- Toggle states for F3 HUD, Full Bright, Drop button, Zoom, Stronghold helper
- Start/Pause/Reset timer
- Movable floating V button

## Not connected to Minecraft yet
The toggles are UI prototypes only. This app does not currently read Minecraft coordinates,
inject game input, execute `/locate`, change game lighting, or implement real zoom/drop actions.
Those require separate, version-specific integration and Android permissions/capabilities.

## Build
AndroidIDE: open the `vortex_client` folder, then use its project build/Gradle action.
This archive intentionally does not include a Gradle wrapper JAR; AndroidIDE's own Gradle environment
should be used. If the app asks for Gradle setup, choose a compatible Gradle 8.9 / Android Gradle
Plugin 8.7.3 configuration.
