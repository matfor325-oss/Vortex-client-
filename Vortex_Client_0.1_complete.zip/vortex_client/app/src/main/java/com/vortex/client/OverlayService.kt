package com.vortex.client

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private var expanded = false
    private val enabled = mutableMapOf<String, Boolean>()
    private var timerRunning = false
    private var elapsed = 0
    private val handler = Handler(Looper.getMainLooper())
    private val timerLabel = TextView(this)
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun overlayParams(): WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(18); y = dp(180) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bubbleParams = overlayParams()
        makeBubble()
    }
    private fun makeBubble() {
        val b = TextView(this).apply {
            text = "V"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF2389D7.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        bubble = b
        b.setOnClickListener { toggleMenu() }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.rawX-sx)>dp(5) || kotlin.math.abs(e.rawY-sy)>dp(5)) moved=true
                        if (moved) { bubbleParams.x=ox+(e.rawX-sx).toInt(); bubbleParams.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(b,bubbleParams) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> { if(!moved) toggleMenu(); return true }
                }
                return false
            }
        })
        wm.addView(b, bubbleParams)
    }
    private fun toggleMenu() {
        if (expanded) { menu?.let { wm.removeView(it) }; menu=null; expanded=false; return }
        val panel = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xEE182436.toInt())
        }
        val header = TextView(this).apply { text="VORTEX TOOLS"; textSize=16f; setTextColor(Color.WHITE); setPadding(0,0,0,dp(8)) }
        panel.addView(header)
        listOf("F3 HUD","Full Bright","Drop Item","Zoom","Stronghold").forEach { label ->
            val row = Button(this).apply { text="$label: ${if(enabled[label]==true) "ON" else "OFF"}" }
            row.setOnClickListener {
                enabled[label]=!(enabled[label]?:false)
                row.text="$label: ${if(enabled[label]==true) "ON" else "OFF"}"
            }
            panel.addView(row)
        }
        val timerRow=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        timerLabel.apply { text=fmt(); textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(dp(6),dp(8),dp(6),dp(8)) }
        timerRow.addView(timerLabel, LinearLayout.LayoutParams(0,dp(48),1f))
        val start=Button(this).apply { text=if(timerRunning) "Pause" else "Start" }
        start.setOnClickListener { timerRunning=!timerRunning; start.text=if(timerRunning) "Pause" else "Start"; if(timerRunning) tick() }
        val reset=Button(this).apply { text="Reset" }
        reset.setOnClickListener { timerRunning=false; elapsed=0; timerLabel.text=fmt(); start.text="Start" }
        timerRow.addView(start); timerRow.addView(reset); panel.addView(timerRow)
        val close=Button(this).apply { text="Close" }
        close.setOnClickListener { toggleMenu() }; panel.addView(close)
        val p=overlayParams().apply { x=bubbleParams.x; y=bubbleParams.y+dp(60) }
        wm.addView(panel,p); menu=panel; expanded=true
    }
    private fun tick() {
        handler.postDelayed({
            if(timerRunning) { elapsed++; timerLabel.text=fmt(); tick() }
        },1000)
    }
    private fun fmt(): String = "%02d:%02d".format(elapsed/60,elapsed%60)
    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch(_:Exception){} }
        menu?.let { try { wm.removeView(it) } catch(_:Exception){} }
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
