package com.vortex.client

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "VORTEX CLIENT"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(0xFFF4F7FC.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Bedrock 1.26.60.04 • Floating tools"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF9DB0C8.toInt())
        }
        val info = TextView(this).apply {
            text = "Prototype 0.1\n\nEnable the floating V button. This first build is a UI prototype; game integration is not connected yet."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFD7E2F0.toInt())
        }
        val btn = Button(this).apply { text = "Enable Vortex floating button" }
        root.addView(title)
        root.addView(subtitle)
        root.addView(info)
        root.addView(btn)
        setContentView(root)
        btn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
            }
        }
    }
    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
    }
}
