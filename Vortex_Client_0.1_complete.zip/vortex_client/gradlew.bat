@echo off
echo AndroidIDE project: use AndroidIDE's Gradle/Build menu.
echo Gradle wrapper JAR is not bundled in this source archive.
exit /b 1
